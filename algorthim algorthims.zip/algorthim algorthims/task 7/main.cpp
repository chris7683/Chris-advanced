#include<iostream>
#include<vector>
#include<stack>
#include<tuple>

using namespace std;

vector<vector<int>> grid = { {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,1,1,1,1,1,1,1,1,1,1,1,1,1,1},{0,0,0,0,0,1,0,1,0,1,0,0,0,0,0},{0,1,1,1,0,1,0,1,0,1,0,1,1,1,0},
                             {0,1,0,1,0,1,0,1,0,1,0,1,0,1,0},{0,1,0,1,1,1,0,1,0,1,1,1,0,1,0},{0,1,0,1,0,0,0,1,0,0,0,1,0,1,0},{0,0,0,1,1,1,1,1,1,1,1,1,0,0,0,},
                             {0,1,0,1,0,0,0,0,0,0,0,1,0,1,0},{0,1,0,1,1,1,1,0,1,1,1,1,0,1,0},{0,1,0,1,0,0,0,0,0,0,0,1,0,1,0},{0,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
                             {0,0,0,0,0,0,0,1,0,0,0,0,0,0,0},{1,1,1,1,1,1,1,1,1,1,1,1,1,1,0}, {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0} };



vector<tuple<int, int>> dfs(tuple<int, int> start, tuple<int, int> end) {
vector<tuple<int, int>> moves = { {0, 1}, {1, 1}, {1, 0}, {-1, 0}, {0, -1}, {-1, -1} };
vector<tuple<int, int>> visited;
stack<tuple<int, int>> q;
visited.push_back(make_tuple(get<0>(start), get<1>(start)));
q.push(start);
while (!q.empty()) {
tuple<int, int> node = q.top();
q.pop();
if (node == end)
return visited;
for (tuple<int, int> move : moves) {
if (0 <= get<0>(node) + get<0>(move) && get<0>(node) + get<0>(move) < 15 && 0 <= get<1>(node) + get<1>(move) && get<1>(node) + get<1>(move) < 15 &&
grid[get<0>(node) + get<0>(move)][get<1>(node) + get<1>(move)] == 1) {
bool test = true;
for (tuple<int, int> a : visited) {
if (make_tuple(get<0>(node) + get<0>(move), get<1>(node) + get<1>(move)) == a)
test = false;
}
if (test) {
q.push(make_tuple(get<0>(node) + get<0>(move), get<1>(node) + get<1>(move)));
visited.push_back(make_tuple(get<0>(node) + get<0>(move), get<1>(node) + get<1>(move)));
}
}
}
}
return visited;
}



int main() {
    tuple<int, int> s = { 13,0 };
    tuple<int, int> e = { 1,14 };
    vector<tuple<int, int>> answer = dfs(s, e);
    for (tuple<int, int> a : answer) {
        cout << "(" << get<0>(a) << "," << get<1>(a) << ")\t";
    }
    cout << endl;
    for (int i = 0; i < 16; i++) {
        for (int j = 0; j < 15; j++) {
            if (i == 0)
                cout << "   " << j + 1;
            else {
                if (grid[i - 1][j] == 0) {
                    if (j == 0 && i <= 9)
                        cout << "  #";
                    else if (j == 0)
                        cout << " #";
                    else if (j > 9)
                        cout << "    #";
                    else
                        cout << "   #";
                }
                else {
                    if (j == 0 && i <= 9)
                        cout << "   ";
                    else if (j == 0)
                        cout << "  ";
                    else if (j > 9)
                        cout << "     ";
                    else
                        cout << "    ";
                }
            }
        }
        if (i < 15)
            cout << endl << i+1;
    }
}