#include <iostream>
#include <algorithm>
using namespace std;

string anagrams(string x, string y) {
    if (x.size() != y.size()) {
        return "No";
    } else {
        sort(x.begin(), x.end());
        sort(y.begin(), y.end());

        if (x != y) {
            return "No";
        } else {
            return "yes";
        }
    }
}

int main() {
    string str1, str2;
    cout << "Enter first string: ";
    cin >> str1;
    cout << "Enter second string: ";
    cin >> str2;

    cout << anagrams(str1, str2) << endl;
    return 0;
}
