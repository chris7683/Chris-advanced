#include <iostream>
using namespace std;

void findFakeCoin(int arr[], int n) {
    if (arr[0] != arr[1]) {
        if (arr[0] == arr[2]) {
            cout << "second coin is fake ans the weight is: " << arr[1] << endl;
        } else if (arr[1] == arr[2]) {
            cout << "first coin is the fake one, and its weight is " << arr[0] << endl;
        } else {
            cout << "third coin is the fake one, and its weight is " << arr[2] << endl;
        }
    } else {

        for (int i = 2; i < n; i++) {
            if (arr[i] != arr[0]) {
                cout << "The fake coin is at position " << i + 1 << " and its weight is: " << arr[i] << endl;
                return;
            }
        }
        cout << "No fake coin found." << endl;
    }
}

int main() {
    int coins[] = {1, 1, 1, 2, 1, 1};
    int n = sizeof(coins) / sizeof(coins[0]);

    findFakeCoin(coins, n);
    return 0;
}
