#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <fstream>
#include <iomanip>


using namespace std;

// Function to generate random array
vector<int> generate_random_array(int size) {
    vector<int> arr(size);
    for (int& val : arr) {
        val = rand() % 100; // Random numbers in range [0, 99]
    }
    return arr;
}

// Helper functions for heap sort
void min_heapify(int arr[], int n, int i, int& comparisons) {
    int smallest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && ++comparisons && arr[left] < arr[smallest]) {
        smallest = left;
    }
    if (right < n && ++comparisons && arr[right] < arr[smallest]) {
        smallest = right;
    }

    if (smallest != i) {
        swap(arr[i], arr[smallest]);
        min_heapify(arr, n, smallest, comparisons);
    }
}

int heap_sort_count(int arr[], int n) {
    int comparisons = 0;

    // Build heap
    for (int i = n / 2 - 1; i >= 0; --i) {
        min_heapify(arr, n, i, comparisons);
    }

    // Extract elements from heap
    for (int i = n - 1; i > 0; --i) {
        swap(arr[0], arr[i]);
        min_heapify(arr, i, 0, comparisons);
    }

    return comparisons;
}

int bubble_sort_count(int arr[], int n) {
    int comparisons = 0;
    bool swapped;
    for (int i = 0; i < n - 1; ++i) {
        swapped = false;
        for (int j = 0; j < n - i - 1; ++j) {
            ++comparisons;
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
                swapped = true;
            }
        }
        if (!swapped) break;
    }
    return comparisons;
}

int selection_sort_count(int arr[], int n) {
    int comparisons = 0;
    for (int i = 0; i < n - 1; ++i) {
        int min_idx = i;
        for (int j = i + 1; j < n; ++j) {
            ++comparisons;
            if (arr[j] < arr[min_idx]) {
                min_idx = j;
            }
        }
        swap(arr[min_idx], arr[i]);
    }
    return comparisons;
}

int insertion_sort_count(int arr[], int n) {
    int comparisons = 0;
    for (int i = 1; i < n; ++i) {
        int key = arr[i];
        int j = i - 1;

        while (j >= 0 && ++comparisons && arr[j] > key) {
            arr[j + 1] = arr[j];
            --j;
        }
        arr[j + 1] = key;
    }
    return comparisons;
}

// Function to test sorting algorithms
void test_comparisons() {
    const int MAX_SIZE = 30;
    const int TEST_CASES = 30;

    ofstream comparisons_file("comparisons.csv");
    ofstream time_file("execution_time.csv");

    comparisons_file << "Size,Heap,Bubble,Selection,Insertion\n";
    time_file << "Size,Heap,Bubble,Selection,Insertion\n";

    for (int size = 1; size <= MAX_SIZE; ++size) {
        long long heap_comparisons = 0, bubble_comparisons = 0;
        long long selection_comparisons = 0, insertion_comparisons = 0;
        double heap_time = 0, bubble_time = 0;
        double selection_time = 0, insertion_time = 0;

        for (int test = 0; test < TEST_CASES; ++test) {
            // Generate random, sorted, and inversely-sorted arrays
            vector<int> random_array = generate_random_array(size);
            vector<int> sorted_array = random_array;
            sort(sorted_array.begin(), sorted_array.end());
            vector<int> inverse_array = sorted_array;
            reverse(inverse_array.begin(), inverse_array.end());

            int temp[size];

            // Test heap sort
            copy(random_array.begin(), random_array.end(), temp);
            auto start = chrono::high_resolution_clock::now();
            heap_comparisons += heap_sort_count(temp, size);
            auto end = chrono::high_resolution_clock::now();
            heap_time += chrono::duration<double>(end - start).count();

            // Test bubble sort
            copy(random_array.begin(), random_array.end(), temp);
            start = chrono::high_resolution_clock::now();
            bubble_comparisons += bubble_sort_count(temp, size);
            end = chrono::high_resolution_clock::now();
            bubble_time += chrono::duration<double>(end - start).count();

            // Test selection sort
            copy(random_array.begin(), random_array.end(), temp);
            start = chrono::high_resolution_clock::now();
            selection_comparisons += selection_sort_count(temp, size);
            end = chrono::high_resolution_clock::now();
            selection_time += chrono::duration<double>(end - start).count();

            // Test insertion sort
            copy(random_array.begin(), random_array.end(), temp);
            start = chrono::high_resolution_clock::now();
            insertion_comparisons += insertion_sort_count(temp, size);
            end = chrono::high_resolution_clock::now();
            insertion_time += chrono::duration<double>(end - start).count();
        }

        // Average the results
        comparisons_file << size << ","
                         << heap_comparisons / TEST_CASES << ","
                         << bubble_comparisons / TEST_CASES << ","
                         << selection_comparisons / TEST_CASES << ","
                         << insertion_comparisons / TEST_CASES << "\n";

        time_file << size << ","
                  << fixed << setprecision(6)
                  << heap_time / TEST_CASES << ","
                  << bubble_time / TEST_CASES << ","
                  << selection_time / TEST_CASES << ","
                  << insertion_time / TEST_CASES << "\n";
    }

    comparisons_file.close();
    time_file.close();
    cout << "Results saved to comparisons.csv and execution_time.csv\n";
}

int main() {
    test_comparisons();
    return 0;
}
