#include <iostream>
#include <vector>
using namespace std;

int arrangeDisks(vector<char>& disks) {
    int moves = 0;
    bool sorted = false;
    int n = disks.size() / 2;

    while (!sorted) {
        sorted = true;
        for (int i = 0; i < 2 * n - 1; i++) {

            if (disks[i] == 'D' && disks[i + 1] == 'L') {
                swap(disks[i], disks[i + 1]);
                moves++;
                sorted = false;
            }
        }
    }
    return moves;
}

void printDisks(const vector<char>& disks) {
    for (char disk : disks) {
        cout << disk << " ";
    }
    cout << endl;
}

int main() {
    vector<char> disks = {'D', 'L', 'D', 'L', 'D', 'L', 'D', 'L'};

    printDisks(disks);
    int moves = arrangeDisks(disks);
    printDisks(disks);
    cout << "moves " << moves << endl;

    return 0;
}
