#include <iostream>
#include <vector>
using namespace std;


void linemaking(string *lns,int sz,int wth,int i, int &length){
    if (i<sz){
        if (lns[i].size() + length > wth) {
            // Word does not fit in the current line
            if (i > 0) {
                lns[i - 1].append("\n");
            }
            length = lns[i].size();
        } else if (lns[i].size() + length == wth) {
            // Word fits exactly
            lns[i].append("\n");
            length = 0;
        } else {
            // Word fits within the current line
            length += lns[i].size();
        }
        linemaking(lns,sz,wth,++i,length);

    }
}
int main() {
    string *s=new string[8];
    cout<<"enter line width\n";
    int wth;
    cin>>wth;
    string word;
    for (int i=0;i<8;i++){
        cout<<"please enter a word\n";
        cin>>word;
        s[i]=word;
    }
    int length=0;
    linemaking(s,13,wth,0,length);
    for (int i=0;i<13;i++){
        cout<<s[i]<<" ";
    }
    return 0;
}

