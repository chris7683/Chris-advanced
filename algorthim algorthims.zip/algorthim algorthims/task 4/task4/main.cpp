#include<iostream>

using namespace std;
int recursive(int x, char a, char b, char c, int &count) {
	if (x == 0) {
		return count;
	}
	recursive(x - 1, a, b, c,count);
	if (x >= 1) {
		cout << x << " from " << a << " to " << b << endl;
		count += 1;
	}
	recursive(x - 1, c, b, a,count);
	cout << x << " from " << b << " to " << c << endl;
	count += 1;
	recursive(x - 1, a, b, c,count);
	return count;
}

int main() {
	cout << "enter a number\n";
	int x;
	cin >> x;
	int n = 0;
	recursive(x, 'a', 'b', 'c',n);
	cout << n << endl;
	return 0;
}

